export { productosRoutes } from './productos.routes';
