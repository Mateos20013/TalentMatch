import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  InjectionToken
} from "./chunk-WV253EFK.js";

// node_modules/@angular/material/fesm2022/input-value-accessor.mjs
var MAT_INPUT_VALUE_ACCESSOR = new InjectionToken("MAT_INPUT_VALUE_ACCESSOR");

export {
  MAT_INPUT_VALUE_ACCESSOR
};
//# sourceMappingURL=chunk-5JFGFLAJ.js.map
